import pickle
import numpy as np

# Load model
model = pickle.load(open("churn_model.pkl", "rb"))

# Load scaler
scaler = pickle.load(open("scaler.pkl", "rb"))

# Sample input (example values)
# Order must match training features: [tenure, MonthlyCharges, TotalCharges]
sample = np.array([[50, 100, 2000]])

# Scale input
sample_scaled = scaler.transform(sample)

# Predict
prediction = model.predict(sample_scaled)
print("prediction:", prediction)
