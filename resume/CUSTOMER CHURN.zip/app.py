import streamlit as st
import pickle
import numpy as np
import pandas as pd
import json
import os
import plotly.express as px
import plotly.graph_objects as go

# -------------------- PAGE CONFIG --------------------
st.set_page_config(
    page_title="Premium Churn Prediction System",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# -------------------- CUSTOM CSS (PREMIUM DESIGN) --------------------
st.markdown("""
<style>
* {
    margin: 0;
    padding: 0;
}

.stApp {
    background: #0b1524;
    background-image: 
        radial-gradient(circle at 25% 15%, rgba(0, 212, 255, 0.22), transparent 55%),
        radial-gradient(circle at 80% 25%, rgba(255, 255, 255, 0.12), transparent 50%),
        linear-gradient(135deg, #0b1524 0%, #121a33 55%, #0f1e3d 100%);
    background-attachment: fixed;
    color: #ffffff;
    min-height: 100vh;
}

h1, h2, h3 {
    text-align: center;
    font-weight: 700;
    letter-spacing: 1px;
}

h1 {
    font-size: 3em;
    margin-bottom: 0.5em;
    background: linear-gradient(90deg, #00d4ff, #0099ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.block-container {
    padding-top: 2.5rem;
    padding-left: 2rem;
    padding-right: 2rem;
}

.stButton>button {
    background: linear-gradient(90deg, #00d4ff, #0099ff);
    color: white;
    border-radius: 12px;
    height: 3.2em;
    width: 100%;
    font-size: 16px;
    font-weight: 600;
    border: none;
    box-shadow: 0 8px 16px rgba(0, 212, 255, 0.3);
    transition: all 0.3s ease;
}

.stButton>button:hover {
    background: linear-gradient(90deg, #0099ff, #00d4ff);
    box-shadow: 0 12px 24px rgba(0, 212, 255, 0.5);
    transform: translateY(-2px);
}

.premium-card {
    padding: 25px;
    border-radius: 20px;
    background: linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.2);
    margin-bottom: 25px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.metric-box {
    padding: 20px;
    border-radius: 15px;
    background: linear-gradient(135deg, rgba(0, 212, 255, 0.1), rgba(0, 153, 255, 0.1));
    border: 2px solid rgba(0, 212, 255, 0.3);
    text-align: center;
    margin: 10px 0;
}

.metric-value {
    font-size: 2.5em;
    font-weight: 700;
    color: #00d4ff;
    margin: 10px 0;
}

.metric-label {
    font-size: 1em;
    color: rgba(255,255,255,0.8);
    font-weight: 500;
}

.error-box {
    padding: 15px;
    border-radius: 10px;
    background-color: rgba(255, 59, 48, 0.15);
    border-left: 4px solid #ff3b30;
    color: #ff3b30;
    margin: 15px 0;
    font-weight: 500;
}

.success-box {
    padding: 15px;
    border-radius: 10px;
    background-color: rgba(34, 197, 94, 0.15);
    border-left: 4px solid #22c55e;
    color: #22c55e;
    margin: 15px 0;
    font-weight: 500;
}

.warning-box {
    padding: 15px;
    border-radius: 10px;
    background-color: rgba(251, 146, 60, 0.15);
    border-left: 4px solid #fb923c;
    color: #fb923c;
    margin: 15px 0;
    font-weight: 500;
}

.range-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-weight: 700;
    font-size: 0.95rem;
    margin: 0 4px 4px 0;
}

.range-badge--tenure {
    background: rgba(0, 212, 255, 0.2);
    color: #00d4ff;
}

.range-badge--monthly {
    background: rgba(34, 197, 94, 0.2);
    color: #22c55e;
}

.range-badge--total {
    background: rgba(255, 59, 48, 0.2);
    color: #ff3b30;
}

.range-text {
    color: rgba(255, 255, 255, 0.9);
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.stNumberInput>label {
    color: #ffffff !important;
    font-weight: 600 !important;
}

.section-divider {
    margin: 30px 0;
    border-top: 2px solid rgba(255,255,255,0.2);
}
</style>
""", unsafe_allow_html=True)

# -------------------- TITLE --------------------
st.markdown(
    "<h1 style='text-align:center; margin-bottom: 0;'>📊 Customer Churn Prediction</h1>\n" 
    "<div style='text-align:center; color: rgba(255,255,255,0.8); margin-bottom: 1rem;'><u>Customer Churn Prediction Analytics Dashboard</u></div>",
    unsafe_allow_html=True
)

# -------------------- LOAD MODEL --------------------
try:
    model = pickle.load(open("churn_model.pkl", "rb"))
    scaler = pickle.load(open("scaler.pkl", "rb"))
except FileNotFoundError:
    st.error("❌ Model files not found. Please run train_model.py first!")
    st.stop()

# -------------------- SESSION STATE --------------------
HISTORY_FILE = "prediction_history.json"

if "history" not in st.session_state:
    st.session_state.history = []

# Load persisted history (if exists)
if os.path.exists(HISTORY_FILE):
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            saved = json.load(f)
            if isinstance(saved, list):
                st.session_state.history = saved
    except Exception:
        # If file is invalid, ignore and continue with empty history
        pass

# -------------------- INPUT SECTION WITH VALIDATION --------------------
st.markdown('<div class="premium-card">', unsafe_allow_html=True)
st.subheader("📥 Customer Profile Analysis")

col1, col2, col3 = st.columns(3)

with col1:
    tenure = st.number_input(
        "📅 Tenure (months)",
        min_value=0,
        max_value=100,
        value=0,
        help="Customer tenure in months (0-100)"
    )

with col2:
    monthly_charges = st.number_input(
        "💰 Monthly Charges ($)",
        min_value=0.0,
        max_value=150.0,
        value=0.0,
        step=0.01,
        help="Monthly billing amount (0-$150)"
    )

with col3:
    total_charges = st.number_input(
        "💵 Total Charges ($)",
        min_value=0.0,
        max_value=10000.0,
        value=0.0,
        step=0.01,
        help="Cumulative total charges (0-$10,000)"
    )

st.markdown('</div>', unsafe_allow_html=True)

# -------------------- INPUT GUIDANCE --------------------
st.markdown(
    "<div class='range-text'>Enter values within allowed ranges:</div>"
    "<div>\n"
    "  <span class='range-badge range-badge--tenure'>Tenure: 0–100</span>\n"
    "  <span class='range-badge range-badge--monthly'>Monthly: $0–$150</span>\n"
    "  <span class='range-badge range-badge--total'>Total: $0–$10,000</span>\n"
    "</div>",
    unsafe_allow_html=True
)

# -------------------- INPUT VALIDATION --------------------
validation_errors = []

if tenure < 0:
    validation_errors.append("❌ Tenure cannot be negative")
if monthly_charges < 0:
    validation_errors.append("❌ Monthly charges cannot be negative")
if total_charges < 0:
    validation_errors.append("❌ Total charges cannot be negative")

if total_charges > 0 and tenure > 0:
    avg_monthly = total_charges / tenure
    if abs(avg_monthly - monthly_charges) > 50:
        validation_errors.append(f"⚠️ Warning: Mismatch detected! Average monthly ({avg_monthly:.2f}) differs from input ({monthly_charges})")

if validation_errors:
    for error in validation_errors:
        st.markdown(f'<div class="error-box">{error}</div>', unsafe_allow_html=True)

# -------------------- PREDICTION --------------------
if st.button("🚀 Generate Prediction"):
    if validation_errors:
        st.markdown('<div class="error-box">❌ Please fix the errors above before proceeding</div>', unsafe_allow_html=True)
    else:
        sample = np.array([[tenure, monthly_charges, total_charges]])
        sample_scaled = scaler.transform(sample)

        prediction = model.predict(sample_scaled)[0]
        probability = model.predict_proba(sample_scaled)[0]

        churn_prob = round(probability[1] * 100, 2)
        stay_prob = round(probability[0] * 100, 2)

        result = "CHURN ❌" if prediction == 1 else "NOT CHURN ✅"

        # Display result with premium styling
        st.markdown('<div class="premium-card">', unsafe_allow_html=True)
        st.subheader("🎯 Prediction Result")

        result_col1, result_col2 = st.columns(2)

        with result_col1:
            if prediction == 1:
                st.markdown(f'<div class="metric-box"><div class="metric-label">⚠️ CHURN RISK</div><div class="metric-value">{churn_prob}%</div><div class="metric-label">High Risk Customer</div></div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="metric-box"><div class="metric-label">✅ RETENTION LIKELY</div><div class="metric-value">{stay_prob}%</div><div class="metric-label">Low Risk Customer</div></div>', unsafe_allow_html=True)

        with result_col2:
            st.write("### 📊 Confidence Analysis")
            fig = go.Figure(data=[
                go.Bar(x=['Churn Risk', 'Stay Probability'], y=[churn_prob, stay_prob],
                       marker_color=['#ff3b30', '#22c55e'])
            ])
            fig.update_layout(
                height=300,
                showlegend=False,
                template='plotly_dark',
                margin=dict(l=0, r=0, t=0, b=0)
            )
            st.plotly_chart(fig, use_container_width=True)

        st.markdown('</div>', unsafe_allow_html=True)

        # Save history
        st.session_state.history.append({
            "Tenure": tenure,
            "Monthly Charges": f"${monthly_charges:.2f}",
            "Total Charges": f"${total_charges:.2f}",
            "Churn Risk %": f"{churn_prob}%",
            "Result": result
        })

        # Persist history to disk
        try:
            with open(HISTORY_FILE, "w", encoding="utf-8") as f:
                json.dump(st.session_state.history, f, indent=2)
        except Exception:
            pass

# -------------------- PREMIUM ANALYTICS DASHBOARD --------------------
if st.session_state.history:
    st.markdown('<div class="section-divider"></div>', unsafe_allow_html=True)

    # -------------------- STATISTICS SECTION --------------------
    st.markdown('<div class="premium-card">', unsafe_allow_html=True)
    st.subheader("📈 Analytics Dashboard")

    df = pd.DataFrame(st.session_state.history)

    stat_col1, stat_col2, stat_col3, stat_col4 = st.columns(4)

    with stat_col1:
        st.markdown(f'''
        <div class="metric-box">
            <div class="metric-label">📊 Total Predictions</div>
            <div class="metric-value">{len(df)}</div>
        </div>
        ''', unsafe_allow_html=True)

    with stat_col2:
        churn_count = len(df[df["Result"] == "CHURN ❌"])
        st.markdown(f'''
        <div class="metric-box">
            <div class="metric-label">⚠️ Churn Cases</div>
            <div class="metric-value">{churn_count}</div>
        </div>
        ''', unsafe_allow_html=True)

    with stat_col3:
        retention_count = len(df[df["Result"] == "NOT CHURN ✅"])
        st.markdown(f'''
        <div class="metric-box">
            <div class="metric-label">✅ Retention Cases</div>
            <div class="metric-value">{retention_count}</div>
        </div>
        ''', unsafe_allow_html=True)

    with stat_col4:
        churn_rate = (churn_count / len(df) * 100) if len(df) > 0 else 0
        st.markdown(f'''
        <div class="metric-box">
            <div class="metric-label">📉 Churn Rate</div>
            <div class="metric-value">{churn_rate:.1f}%</div>
        </div>
        ''', unsafe_allow_html=True)

    st.markdown('</div>', unsafe_allow_html=True)

    # -------------------- CHARTS --------------------
    st.markdown('<div class="premium-card">', unsafe_allow_html=True)
    st.subheader("📊 Detailed Analytics")

    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        st.write("### 🎯 Churn Distribution")
        counts = df["Result"].value_counts()
        fig_pie = go.Figure(data=[go.Pie(
            labels=['Retention ✅', 'Churn ❌'],
            values=[retention_count, churn_count],
            marker=dict(colors=['#22c55e', '#ff3b30']),
            hole=0.4
        )])
        fig_pie.update_layout(height=350, template='plotly_dark', margin=dict(l=0, r=0, t=0, b=0))
        st.plotly_chart(fig_pie, use_container_width=True)

    with chart_col2:
        st.write("### 💰 Average Charges by Outcome")
        churn_df = df[df["Result"] == "CHURN ❌"]
        retention_df = df[df["Result"] == "NOT CHURN ✅"]
        
        avg_data = pd.DataFrame({
            'Outcome': ['Churn ❌', 'Retention ✅'],
            'Avg Monthly': [
                float(churn_df["Monthly Charges"].str.replace('$', '').astype(float).mean()) if len(churn_df) > 0 else 0,
                float(retention_df["Monthly Charges"].str.replace('$', '').astype(float).mean()) if len(retention_df) > 0 else 0
            ]
        })
        
        fig_bar = go.Figure(data=[
            go.Bar(x=avg_data['Outcome'], y=avg_data['Avg Monthly'],
                   marker_color=['#ff3b30', '#22c55e'])
        ])
        fig_bar.update_layout(height=350, template='plotly_dark', margin=dict(l=0, r=0, t=0, b=0))
        st.plotly_chart(fig_bar, use_container_width=True)

    st.markdown('</div>', unsafe_allow_html=True)

    # -------------------- PREDICTION HISTORY TABLE --------------------
    st.markdown('<div class="premium-card">', unsafe_allow_html=True)
    st.subheader("📜 Prediction History")
    st.dataframe(df, use_container_width=True, height=400)
    st.markdown('</div>', unsafe_allow_html=True)

# -------------------- CLEAR BUTTON --------------------
col_clear1, col_clear2, col_clear3 = st.columns([1, 1, 2])

with col_clear1:
    if st.button("🗑 Clear History", use_container_width=True):
        st.session_state.history = []
        try:
            if os.path.exists(HISTORY_FILE):
                os.remove(HISTORY_FILE)
        except Exception:
            pass
        st.success("✅ History cleared successfully!")
        st.rerun()

with col_clear2:
    if st.button("📋 Download Report", use_container_width=True):
        if st.session_state.history:
            df = pd.DataFrame(st.session_state.history)
            csv = df.to_csv(index=False)
            st.download_button(
                label="Download CSV",
                data=csv,
                file_name="churn_predictions.csv",
                mime="text/csv"
            )

# -------------------- FOOTER --------------------
st.markdown("---")
st.markdown(
    "<center>💡 Developed by Supriya Reddy</center>",
    unsafe_allow_html=True
)