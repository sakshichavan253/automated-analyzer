import pandas as pd
import numpy as np
import pickle

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Load dataset
data = pd.read_csv("customer_churn.csv")

# Drop unnecessary columns (if any)
if "customerID" in data.columns:
    data = data.drop("customerID", axis=1)

# Ensure numeric columns are numeric (TotalCharges can contain spaces/missing values)
data["TotalCharges"] = pd.to_numeric(data["TotalCharges"], errors="coerce")

data = data.dropna(subset=["TotalCharges"])

# Use only the core numeric features for training
feature_cols = ["tenure", "MonthlyCharges", "TotalCharges"]
X = data[feature_cols]

# Convert target variable to numeric
if "Churn" in data.columns:
    y = data["Churn"].map({"Yes": 1, "No": 0})
else:
    # Fallback if target column was already encoded
    y = data["Churn_Yes"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train model
model = LogisticRegression()
model.fit(X_train_scaled, y_train)

# Predictions
y_pred = model.predict(X_test_scaled)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print("Model Accuracy:", accuracy)

# Save model
pickle.dump(model, open("churn_model.pkl", "wb"))

# Save scaler
pickle.dump(scaler, open("scaler.pkl", "wb"))

print("Model and scaler saved successfully!")